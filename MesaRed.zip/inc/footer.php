<div class="ResForm"></div>
<div class="ResbeforeSend"></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-info">Contáctanos</h4>
                <a href="https://www.facebook.com/carlostato.brown/" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true">&nbsp; Facebook </i> 
                </a><br>
                <a href="https://twitter.com/CarlosRenato97" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true">&nbsp; Twitter </i>
                </a><br>
                <a href="https://www.youtube.com/user/tato9710/featured" target="_blank">
                    <i class="fa fa-youtube-play" aria-hidden="true">&nbsp; YouTube </i>
                </a><br>
            </div>
            <div class="col-sm-4">
                <h4 class="text-info">¿Quiénes somos?</h4>
                <p> 
                    Somos una página confiable,</br>
                    dedicados únicamente a la venta de LEGOs</br>
                    por excelencia, comprometidos a brindarle</br>
                    la mayor satisfacción posible.</br>
                </p>
            </div>
            <div class="col-sm-4">
                <h4 class="text-info" >Dirección</h4>
                <p style="color: #FFF">Mazatlán, Sinaloa</p>
                <p style="color: #FFF">Rigoberto Aguilar Picos #10512</br>
                Fracc. Los Portales. CP. 82154</p>
                <p class="fa fa-mobile" style="font-size:20px"  aria-hidden="true">  669 272 0996</p> <a href="https://wa.me/526692720996" target="_blank" style="color: #5bc0de">Envíanos un mensaje</a></br>
                E-mail: <a href="mailto:carlos.renato.moreno.lugo@gmail.com" target="_blank" style="color: #5bc0de"> &nbsp; carlos.renato.moreno.lugo@gmail.com</a>
            </div>
        </div>
    </div>
    <br><br><br>
    <img src="assets/img/logo3.png" alt="logo" class="img-responsive" style="width: 10%; display: block; margin: 0 auto;">
</footer>
