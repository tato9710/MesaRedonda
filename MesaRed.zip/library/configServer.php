<?php
define("USER", "root");
define("SERVER", "localhost");
define("BD", "renatoys2");
define("PASS", "");